#!/bin/sh

DBUS_LAUNCH=/bin/dbus-launch

if [ -x "$DBUS_LAUNCH" -a -z "$DBUS_SESSION_BUS_ADDRESS" ]; then
	eval `$DBUS_LAUNCH --sh-syntax --exit-with-session 2>/dev/null`
        export DBUS_SESSION_BUS_ADDRESS DBUS_SESSION_BUS_PID
fi

unset DBUS_LAUNCH
