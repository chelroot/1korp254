# shell functions provides list
Copy
CopyLibs
Fatal
Info
Verbose
copy_resolv_conf
copy_resolv_lib
is_yes
