# define aliases for zsh
[ -n "${ZSH_VERSION}" ] || return 0
alias mc='. /usr/lib/mc/mc-wrapper.sh'
