if test -e /usr/lib/jvm/java; then
    JAVA_HOME=/usr/lib/jvm/java
    export JAVA_HOME
else if test -e /usr/lib/jvm/jre; then
    JRE_HOME=/usr/lib/jvm/jre
    export JRE_HOME
    fi
fi
