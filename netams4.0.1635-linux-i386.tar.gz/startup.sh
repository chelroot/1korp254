#!/bin/sh
#
# NETAMS4 all services startup
#

LANG=ru_RU.UTF-8
export LANG

n4cd=`echo $0 | sed -e 's/startup.sh//'`

cd $n4cd

cd jserver && /bin/sh jserver-startup.sh && cd ..
# cd radius && /bin/sh radius-startup.sh && cd ..

sleep 5
cd webadmin && /bin/sh webadmin-startup.sh && cd ..
# authserver as a separate application is only for large-scale deployment!
# cd webadmin && /bin/sh authserver-startup.sh && cd ..

sleep 5
cd repserver && /bin/sh repserver-startup.sh && cd ..



