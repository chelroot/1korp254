package com.netams.netams4.tariff;

import com.netams.netams4.types.specific;

// basic interface to indicate that this service-specific data is a VPN service, so we can pass some data to RADIUS 
public abstract class VPNServiceSpecific extends specific {

	private static final long serialVersionUID = -4907708867847289549L;
	// to keep previous counters (radius)
	private long last_bytes_in;
	private long last_bytes_out;
	private long last_frames_in;
	private long last_frames_out;

	public long getLastBytes(direction d) { if (d.equals(VPNServiceSpecific.direction.IN)) return last_bytes_in; else return last_bytes_out; }
	public long getLastFrames(direction d) { if (d.equals(VPNServiceSpecific.direction.IN)) return last_frames_in; else return last_frames_out; }
	public void setLastBytes(direction d, long count) { if (d.equals(VPNServiceSpecific.direction.IN)) last_bytes_in = count; else last_bytes_out=count; }
	public void setLastFrames(direction d, long count) { if (d.equals(VPNServiceSpecific.direction.IN)) last_frames_in = count; else last_frames_out=count; }

	public abstract boolean getPermitMultipleLogins();
	
public enum direction {IN, OUT};

}

