package com.netams.netams4.tariff;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.jnetpcap.Pcap;

import com.netams.netams4.BillingEngine;
import com.netams.netams4.datasource.DsAccountingInfo;
import com.netams.netams4.datasource.DsDataType;
import com.netams.netams4.datasource.DsMatchResult;
import com.netams.netams4.structures.Database;
import com.netams.netams4.structures.Event;
import com.netams.netams4.structures.ExceptionManager;
import com.netams.netams4.structures.Tag;
import com.netams.netams4.structures.TagSet;
import com.netams.netams4.structures.Utils;
import com.netams.netams4.tariff.FlatRate2.ServiceSpecific;
import com.netams.netams4.types.AuthInfoState;
import com.netams.netams4.types.DayType;
import com.netams.netams4.types.obj4;
import com.netams.netams4.types.obj4_account;
import com.netams.netams4.types.obj4_acctunit;
import com.netams.netams4.types.obj4_service;
import com.netams.netams4.types.obj4_unidata;
import com.netams.netams4.types.obj4_utilization;
import com.netams.netams4.types.specific;
import com.netams.netams4.types.ss_tariff;

public class PolicyBasedEngine extends TariffEngine {
	private static final String DEFAULT_CONFIG_FILE_NAME = "pbe.cfg";
	private String config_file;
	static Logger logger = Logger.getLogger(PolicyBasedEngine.class);

	private Policy policy;
	private boolean matched_conditions[];
	private boolean matched_conditions_res[];
	
	public Vector<Accounting> getAccountings() { return policy.accounting_v; }

	class ServiceSpecific extends specific {
		private static final long serialVersionUID = 1237863406100318761L;
		class data {
			Accounting acct;
			long t_in=0;
			long t_out=0;
			double c_in=0;
			double c_out=0;
		}
		private HashMap<Accounting,data> info;
		
		public ServiceSpecific(){
			info = new HashMap<Accounting,data>(policy.accounting_v.size());	
			for (Accounting a : policy.accounting_v) {
				data tmp = new data();
				tmp.acct = a;
				info.put(a, tmp);
			}
		}
		
		public synchronized void balance(obj4_account ac, double cost) {
			synchronized (ac) {
				double c = ac.getBalance();
				c+=cost;
				ac.setBalance(c);
			}
		}
		

		public double update(Accounting accounting, long octets, DsMatchResult mr) {
			data to_update=info.get(accounting);
			double charge = 0;
			if (to_update!=null) {
				if (mr.getKey() == DsMatchResult.MATCH_SRC) {
					to_update.t_out+=octets;
					charge = accounting.out_rate*octets/accounting.multiplier;
					to_update.c_out-=charge;
				}
				else if (mr.getKey() == DsMatchResult.MATCH_DST) {
					to_update.t_in+=octets;
					charge = accounting.in_rate*octets/accounting.multiplier;
					to_update.c_in-=charge;
				}
				else if (mr.getKey() == DsMatchResult.MATCH_BOTH) {
					to_update.t_in+=octets;
					to_update.t_out+=octets;
					charge =  accounting.in_rate*octets/accounting.multiplier + accounting.out_rate*octets/accounting.multiplier;
					to_update.c_in-=accounting.in_rate*octets/accounting.multiplier;
					to_update.c_out-=accounting.out_rate*octets/accounting.multiplier;
				}
				is_dirty=true;
				//logger.info("ServiceSpecific update: accounting:"+accounting.name+" bytes="+octets+", MR="+mr+", charge="+charge);
			}
			return charge;
		}

		public void flush_utilization(int service_id, Vector<obj4> data) {
			synchronized (info) {
				for (data tmp : info.values()) {
					if (!(tmp.t_in==0 && tmp.c_in==0)) {
						obj4_utilization ou_in = new obj4_utilization();
						ou_in.setService_id(service_id);
						ou_in.setService_key(tmp.acct.in_tag);
						ou_in.setService_volume(tmp.t_in);
						ou_in.setCost(-tmp.c_in);
						data.add(ou_in);
					}
					tmp.t_in=0;
					tmp.c_in=0;
					if (!(tmp.t_out==0 && tmp.c_out==0)) {
						obj4_utilization ou_out = new obj4_utilization();
						ou_out.setService_id(service_id);
						ou_out.setService_key(tmp.acct.out_tag);
						ou_out.setService_volume(tmp.t_out);
						ou_out.setCost(-tmp.c_out);
						data.add(ou_out);
					}
					tmp.t_out=0;
					tmp.c_out=0;
				}
				is_dirty=false;
			}

		}
	}

	public PolicyBasedEngine() {
		parameters.add(new ss_tariff(
				"Policy configuration file", 
				"Configuration file path relative to \"jserver/db/\" directory, or absolute, String", 
				"config_file", DEFAULT_CONFIG_FILE_NAME, ss_tariff.paramtype.STRING, null));
	}

	@Override
	public int add_acctunit(obj4_acctunit unit) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public AuthInfoState service_action(Event.event_type action, obj4_service newS, obj4_service oldS, obj4_account ac) {
		if (action==Event.event_type.SERVICE_ADD || action==Event.event_type.SERVICE_MOD) return add_funds(newS, ac);
		else return AuthInfoState.PERMIT;
	}

	@Override
	public AuthInfoState ds_accounting(obj4_acctunit au, obj4_service s, obj4_account ac, DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		if (ac==null) return null; // strange: where to charge from?
		if (dsItem.octets==0) return null; // why we ever got here??
		ServiceSpecific fvs = (ServiceSpecific) s.getSp();
		if (fvs == null) {
			logger.error("PBE ds_accounting called but no specific info is initialized! (service="+s.getId()+")");
			return null;
			}

		// flush cached matched conditions
		for (int j=0; j<policy.condition_v.size(); j++) { matched_conditions[j]=false; matched_conditions_res[j]=false; } 
		for (Rule rule : policy.rule_v) {
			boolean this_rule_matched=false;
			switch (rule.condition_rule) {
				case Rule.COND_ONLY: {
					this_rule_matched = rule.condition_a.matchCached(au,dsItem,mr,tt);
					break;
				}
				case Rule.COND_NOT: {
					this_rule_matched = ! rule.condition_a.matchCached(au,dsItem,mr,tt);
					break;
				}
				case Rule.COND_AND: {
					this_rule_matched = rule.condition_a.matchCached(au,dsItem,mr,tt);
					if (this_rule_matched) 
						this_rule_matched = rule.condition_b.matchCached(au,dsItem,mr,tt);
					break;
				}
				case Rule.COND_OR: {
					this_rule_matched = rule.condition_a.matchCached(au,dsItem,mr,tt);
					if (this_rule_matched) break; 
					this_rule_matched = rule.condition_b.matchCached(au,dsItem,mr,tt);
					break;
				}
			}
			if (this_rule_matched) {
				// act on Action for this rule
				double charge = fvs.update(rule.accounting, dsItem.octets, mr);
				fvs.balance(ac, -charge);
				// check what to do next
				// logger.info("PBE rule "+rule.accounting.name+" matched for "+dsItem.dump());
				if (rule.next == Next.STOP) break;
				else if (rule.next == Next.CONTINUE) continue;
			} // rule matched
			else ;//logger.info("PBE rule "+rule.accounting.name+" NOT matched for "+dsItem.dump());
		} // loop for all rules

		return add_funds(s, ac); // decision is based on current balance only
	}

	@Override
	public AuthInfoState ds_authorizarion(obj4_acctunit au, obj4_service s, obj4_account ac, DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean init_service_runtime(obj4_service s, boolean at_start){
		ServiceSpecific fvs = (ServiceSpecific) s.getSp();
		if (fvs == null) {
			if (!at_start) logger.info("PBE init_service_runtime create service-specific (service="+s.getId()+")");
			fvs = new ServiceSpecific();
			s.setSp(fvs);
		}
		return true;
	}

	@Override
	public String dump() {
		return "configuration file: "+config_file+", policy:\n"+policy.dump();
	}

	@Override
	public String getEngineDescription() {
		return "Policy-Based tariff Engine version 1, charging parameters are specified in the hierarchical policy text file";
	}

	@Override
	public String getEngineName() {
		return "Policy-Based Engine v1";
	}

	@Override
	public int init(Database db) {
		is_customizable_per_service=false;
		currency = db.cfg.Currency.values().iterator().next();
		config_file = DEFAULT_CONFIG_FILE_NAME;
		for (obj4_unidata x: ourtariff.data) {
			if (x.getAttribute_name().equals("config_file")) config_file = x.getAttribute_value();  
		}
		policy = new Policy();
		is_initialized=true;
		int ret = parseConfig(db);
		matched_conditions = new boolean[policy.condition_v.size()];
		matched_conditions_res = new boolean[policy.condition_v.size()];
		int jj=0;
		for (Condition cx : policy.condition_v) {
			cx.refid = jj;
			jj++;
		}
		return ret;
	}

	private int parseConfig(Database db) {
		ConfigBuffer cfg_buffer = new ConfigBuffer();
		if (!loadConfig(db, config_file, cfg_buffer)) return 0;
		try {
			Vector<section> sections = section.parse(cfg_buffer);
			for (section s : sections) {
				//System.err.println("section dump: " + s.dump());
	
				// "prefix-file"
				if (s.name.equals("prefix-file")){
					PrefixFile pf = new PrefixFile();
					pf.id = s.id; if (pf.id==0) pf.name = s.id_name;
					for (String elem : s.elements) {
						String kv[]=section.splitElement(elem);
						if (kv[0].equals("path")) pf.prefix_file_name = kv[1];
						else if (kv[0].equals("reload")) pf.reload = safeParseInt(kv[1]); 
					}
					pf.init(db);
					policy.prefixfile_v.add(pf);
				} 
				// "condition"
				else if (s.name.equals("datetime")){
					DateTime dt = new DateTime(db);
					dt.id = s.id; if (dt.id==0) dt.name = s.id_name;
					for (String elem : s.elements) {
						String kv[]=section.splitElement(elem);
						//logger.debug("kv[0]="+kv[0]+", kv[1]="+kv[1]);
						if (kv[0].equals("daytype")) { 
							if (kv[1].toLowerCase().equals("workingday")) dt.daytype = DayType.WORKINGDAY; 
							else if (kv[1].toLowerCase().equals("weekend")) dt.daytype = DayType.WEEKEND; 
							else if (kv[1].toLowerCase().equals("holiday")) dt.daytype = DayType.HOLIDAY; 
							else if (kv[1].toLowerCase().equals("nonworkingday")) dt.daytype = DayType.NONWORKINGDAY; 
							else if (kv[1].toLowerCase().equals("any")) dt.daytype = null; 
							//logger.debug("DateTime "+dt.name+" daytype "+dt.daytype);
							}
					}// TODO more parsing
					policy.datetime_v.add(dt);
				} 
				// "condition"
				else if (s.name.equals("condition")) {
					Condition cond = new Condition();
					cond.id = s.id; if (cond.id==0) cond.name = s.id_name;
					for (String elem : s.elements) {
						String kv[]=section.splitElement(elem);
						if (kv[0].equals("type")) { if (kv[1].toLowerCase().equals("traffic")) cond.type = Type.TRAFFIC; }
						else if (kv[0].equals("protocol")) {
							if (isAny(kv[1])) cond.protocol=0; 
							else if (kv[1].toLowerCase().equals("ip"))	cond.protocol=0;
							else if (kv[1].toLowerCase().equals("icmp")) cond.protocol=1;
							else if (kv[1].toLowerCase().equals("udp")) cond.protocol=17;
							else if (kv[1].toLowerCase().equals("tcp")) cond.protocol=6;
							else if (kv[1].toLowerCase().equals("gre")) cond.protocol=47;
							else if (kv[1].toLowerCase().equals("ospf")) cond.protocol=89;
						}
						else if (kv[0].equals("srcdst")) { 
							if (isAny(kv[1])) cond.srcdst= null; 
							else { cond.srcdst = new AddrDef(); cond.srcdst.set(kv[1]); }
							}
						else if (kv[0].equals("source")) { 
							if (isAny(kv[1])) cond.source = null; 
							else { cond.source = new AddrDef(); cond.source.set(kv[1]); }
							}
						else if (kv[0].equals("destination")) { 
							if (isAny(kv[1])) cond.destination = null; 
							else { cond.destination = new AddrDef(); cond.destination.set(kv[1]); }
							}
						else if (kv[0].equals("port")) { 
							if (isAny(kv[1])) cond.port=null; 
							else { cond.port = new PortDef(); cond.port.set(kv[1]); }
							}	
						else if (kv[0].equals("src_port")) { 
							if (isAny(kv[1])) cond.src_port=null; 
							else { cond.src_port = new PortDef(); cond.src_port.set(kv[1]); }
							}	
						else if (kv[0].equals("dst_port")) { 
							if (isAny(kv[1])) cond.dst_port=null; 
							else { cond.dst_port = new PortDef(); cond.dst_port.set(kv[1]); }
							}
						else if (kv[0].equals("ds-type")) { /*** TODO ***/  }
						else if (kv[0].equals("ds-tag")) {
							String kvt[] = kv[1].split("=");
							if (kvt.length==2 && kvt[1]!=null) cond.dstag = new Tag(kvt[0], kvt[1]); 
						}
						else if (kv[0].equals("datetime")) {
							if (kv[1].toLowerCase().equals("any")) cond.datetime = null; 
							else { 
								int j = safeParseInt(kv[1]);
								DateTime dt = null;
								if (j!=0) {
									for (DateTime tmp : policy.datetime_v) if (tmp.id==j) { dt=tmp; break; }
								} else {
									for (DateTime tmp : policy.datetime_v) if (tmp.name.equals(kv[1])) { dt=tmp; break; }
								}
								if (dt!=null) cond.datetime=dt;
							}
						}
					}
					policy.condition_v.add(cond);
				}
				// "accounting"
				else if (s.name.equals("accounting")) {
					Accounting acc = new Accounting();
					acc.id = s.id;  if (acc.id==0) acc.name = s.id_name;
					for (String elem : s.elements) {
						String kv[]=section.splitElement(elem);
						if (kv[0].equals("multiplier")) { 
							if (kv[1].toLowerCase().startsWith("kilobyte")) acc.multiplier = 1024;
							else if (kv[1].toLowerCase().startsWith("megabyte")) acc.multiplier = 1024*1024;
							else if (kv[1].toLowerCase().startsWith("gigabyte")) acc.multiplier = 1024*1024*1024;
						}
						else if (kv[0].equals("name")) {
							acc.title = new String(kv[1]);
						}
					}
					for (section sx : s.inner) {
						if (sx.name.equals("direction")) {
							Double rate=0.0; 
							String tag="traffic-";
							for (String sxx : sx.elements) {
								String kv[]=section.splitElement(sxx);
								if (kv[0].equals("tag")) tag=kv[1];
								else if (kv[0].equals("rate")) rate = Utils.parseDouble(kv[1]);
							}
							if (sx.id_name.equals("input")) {
								acc.in_rate = rate;
								acc.in_tag = tag;
							} else if (sx.id_name.equals("output")) {
								acc.out_rate = rate;
								acc.out_tag = tag;
							}
						}
					}
					policy.accounting_v.add(acc);
				}
				// "rule"
				else if (s.name.equals("rule")) {
					Rule rul = new Rule();
					rul.id = s.id;
					for (String elem : s.elements) {
						String kv[]=section.splitElement(elem);
						if (kv[0].equals("condition")) {
							int space1=-1, space2=-1;
							space1 = kv[1].indexOf(' ');
							if (space1!=-1) space2 = kv[1].indexOf(' ', space1+1);
							if (space1==-1) { // "cond_name"
								Condition cc=policy.getCondition(kv[1]);
								if (cc==null) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' (referring to unknown condition '"+kv[1]+"')");
								rul.condition_a = cc; rul.condition_rule = Rule.COND_ONLY;
							} else if (space1!=-1 && space2==-1) { // likely "NOT cond_name" 
								String val[] = kv[1].split("\\s+");
								if (val.length!=2) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' ('NOT' condition)");
								if (!val[0].equalsIgnoreCase("NOT")) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' (no 'NOT' prefix)");
								Condition cc=policy.getCondition(val[1]);
								if (cc==null) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' ('NOT' prefix referring to unknown condition '"+val[1]+"')");
								rul.condition_a = cc; rul.condition_rule = Rule.COND_NOT;
							} else if (space1!=-1 && space2!=-1) { // likely "cond_name AND/OR cond_name"
								String val[] = kv[1].split("\\s+");
								if (val.length!=3) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' ('A/N' condition)");
								Condition cca=policy.getCondition(val[0]);
								if (cca==null) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' (first condition referring to unknown '"+val[0]+"')");
								rul.condition_a = cca; 
								Condition ccb=policy.getCondition(val[2]);
								if (ccb==null) throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' (second condition referring to unknown '"+val[2]+"')");
								rul.condition_b = ccb; 
								if (val[1].equalsIgnoreCase("AND")) rul.condition_rule = Rule.COND_AND;
								else if (val[1].equalsIgnoreCase("OR")) rul.condition_rule = Rule.COND_OR;
								else throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"' (no 'A/N' part)"); 
							} else throw new Exception("rule "+rul.id+" is referring to malformed condition '"+kv[1]+"'");
						}
						else if (kv[0].equals("accounting")) {
							int j = safeParseInt(kv[1]);
							Accounting cc=null;
							if (j!=0) for (Accounting c : policy.accounting_v) { if (c.id==j) { cc=c; break; } }
							else for (Accounting c : policy.accounting_v) { if (c.name.equals(kv[1])) { cc=c; break; } }
							if (cc!=null) rul.accounting = cc; else throw new Exception("rule "+rul.id+" is referring to non-existing accounting "+(j==0?kv[1]:j));
						}
						else if (kv[0].equals("next")) {
							if (kv[1].equals("continue")) rul.next = Next.CONTINUE; 
							else if (kv[1].equals("stop")) rul.next = Next.STOP; 
						}
						else if (kv[0].equals("filter")) {
							if (kv[1].equals("pass")) rul.filter = Filter.PASS; 
							else if (kv[1].equals("block")) rul.filter = Filter.BLOCK; 
						}
					}
					policy.rule_v.add(rul);
				}
			}
		} catch (Exception x) {
			ExceptionManager.handleError("Syntax error while parsing configuration file, error: \""+x.getMessage()+"\".", x);
			return 0;
		}
		return 1;
	}
	private boolean isAny(String lookup) {
		if (lookup==null) return false;
		else if (lookup.toLowerCase().equals("any")) return true;
		else return false;
	}
	
	private boolean loadConfig(Database db, String filename1, ConfigBuffer cfg_buffer) {
		String config_file_x = filename1;
		if (config_file_x.indexOf('/')==-1 && config_file_x.indexOf('\\')==-1) { // not a full path, adjust
			String xmlmapdirectory = db.getProperties().getProperty("db.cfg.path", "db");
			config_file_x = xmlmapdirectory+"/"+config_file_x;
		}
		// logger.debug("loadConfig: "+filename1+", "+config_file_x);
		int ob=0, cb=0;
		try {
			BufferedReader r = new BufferedReader(new FileReader(config_file_x));
			while (r.ready()) {
				String s = r.readLine();
				if (s!=null )s=s.trim();
				if (s==null || s.equals("\n") || s.isEmpty() || s.indexOf('#')==0) continue; // comments and empty lines
				int j=s.indexOf('#'); if (j>0) s = s.substring(0,j); // trailing comments
				s = s.replaceAll("\t", "");
				if (s.startsWith("include")) {
					String new_filename = s.substring(s.indexOf(' ')+1);
					boolean ret = loadConfig(db, new_filename, cfg_buffer);
					if (ret==false) return false;
				}
				else {
					char[] x = s.toCharArray(); 
					for (int i=0; i<x.length; i++) {
						if (x[i]=='{') ob++;
						else if (x[i]=='}') cb++;
					}
					cfg_buffer.add(s);
				}
			}
		} catch (FileNotFoundException x) {
			ExceptionManager.handleError("Specified configuration file, \""+config_file+"\", is not found.", x);
			return false;
		} catch (IOException x) {
			ExceptionManager.handleError("IO error while reading configuration file, \""+config_file+"\".", x);
			return false;
		}
		if (ob!=cb) {
			logger.error("Syntax error while parsing configuration file, number of open brackets ('{')"+ob+" is not equal to number of closing brackets('}')"+cb+".");
			return false;
		}
		return true;
	}

	@Override
	public boolean isCapable(DsAccountingInfo data) {
		if (data.type == DsDataType.NETFLOW5) return true;
		else if (data.type == DsDataType.PCAP) return true;
		else if (data.type == DsDataType.RAGENT) return true;
		return false;
	}

	@Override
	public int remove_acctunit(obj4_acctunit unit) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	@Override
	public Vector<obj4> sync_specific(obj4_service se) {
		ServiceSpecific fvs = (ServiceSpecific) se.getSp();
		Vector<obj4> data = new Vector<obj4>(fvs.info.size());
		fvs.flush_utilization(se.getId(), data);
		return data;
	}

	@Override
	public int timer_event(Database db, Event evt) {
		// TODO currently may be required for:
		// a) reload prefix file
		for (PrefixFile pf : policy.prefixfile_v){
			if (pf.reload!=0) {
				pf.check();
			}
		}
		// b) update DateTime cached value
		
		return 0;
	}
	
	private static int safeParseInt(String s){
		int ret=0;
		if (s==null) return 0;
		try {
			ret = Integer.parseInt(s);
		} catch (NumberFormatException x) {}
		return ret;
	}
	//###################################################################################
	// service classes required to describe policy
	class Rule {
		static final int COND_ONLY=0;
		static final int COND_AND=1;
		static final int COND_OR=2;
		static final int COND_NOT=3;
		int id;
		Condition condition_a, condition_b;
		int condition_rule;
		Accounting accounting;
		Filter filter;
		Next next;
		public String dump() {
			return "id="+id+
				", condition="+getCondition()+
				", accounting="+(accounting.id==0?accounting.name:accounting.id)+
				", filter="+filter.name()+", next="+next.name();
		}
		private String getCondition() {
			if (condition_rule==COND_ONLY) return "\""+getConditionStr(condition_a)+"\"";
			else if (condition_rule==COND_NOT) return "NOT \""+getConditionStr(condition_a)+"\"";
			else if (condition_rule==COND_AND) return "\""+getConditionStr(condition_a)+"\" AND \""+getConditionStr(condition_b)+"\"";
			else if (condition_rule==COND_OR) return "\""+getConditionStr(condition_a)+"\" OR \""+getConditionStr(condition_b)+"\"";
			else return "<unknown ???>";
		}
		private String getConditionStr(Condition c) { return c.id==0?c.name:(c.id+""); }
	}
	
	class Condition extends Elem {
		public int refid;
		Type type;
		int protocol;
		AddrDef srcdst; // matches source OR/AND destination IP
		AddrDef source; // any # ip_addr, ip_subnet, prefix-file rus-net
		AddrDef destination; // : any
		PortDef port; // matches source OR/AND destination port
		PortDef src_port;// : any
		PortDef dst_port;//  : any
		DsDataType dstype[]; // : any
		Tag dstag; // : any
		DateTime datetime;
		public String dump() {
			return "id="+id+", name="+name+", type="+type.name()+
			", srcdst="+(srcdst==null?"any":srcdst.get())+ 
			", source="+(source==null?"any":source.get())+ 
			", destination="+(destination==null?"any":destination.get())+
			", datetime="+(datetime==null?"any":("["+datetime.dump()+"]")); 
			// TODO more
		}
		public boolean matchCached(obj4_acctunit au, DsAccountingInfo dsItem,	DsMatchResult mr, TagSet tt) {
			if (matched_conditions[refid]) return matched_conditions_res[refid]; 
			else {
				boolean m = match(au, dsItem, mr, tt);
				matched_conditions[refid]=true;
				matched_conditions_res[refid]=m;
				return m;
			}
		}
		public boolean match(obj4_acctunit au, DsAccountingInfo dd, DsMatchResult mr,	TagSet tt) {
			if (protocol!=0 && dd.ip_proto!=protocol) return false;
			if (srcdst!=null && (!srcdst.match(dd.ip_src) && !srcdst.match(dd.ip_dst))) return false;
			if (source!=null && !source.match(dd.ip_src)) return false;
			if (destination!=null && !destination.match(dd.ip_dst)) return false;
			if (dd.ip_proto==6 || dd.ip_proto==17) {
				if (port!=null && (!port.match(dd.src_port) && !port.match(dd.dst_port))) return false;
				if (src_port!=null && !src_port.match(dd.src_port)) return false;
				if (dst_port!=null && !dst_port.match(dd.dst_port)) return false;
			}
			if (dstype!=null) return false; // TODO
			if (dstag!=null) { 
				String t = tt.getTag(dstag.getKey());
				if (t==null) return false;
				return (dstag.getValue().equals(t));
			}
			if (datetime!=null && datetime.match()==false) return false;
			return true;
		}
	}
	
	public class Accounting extends Elem {
		public String title;
		int multiplier;
		public String in_tag, out_tag;
		Double in_rate, out_rate;
		public String dump() {
			return "id="+id+", name="+name+", title=\""+title+"\", mult="+multiplier+", in=["+in_tag+", "+in_rate+"], out=["+out_tag+", "+out_rate+"]";
		}
	}

	enum Filter {PASS, BLOCK; }
	enum Next {CONTINUE, STOP; }
	enum Type {TRAFFIC; }
	
	class PortDef {
		private int port=0;
		private int start_port_range=0, end_port_range=0;
		private int[] port_list=null;
		public void set(String s) {
			int i = s.indexOf('-'); // range
			if (i!=-1) {
				String s1 = s.substring(0, i); s1=s1.trim(); start_port_range = Integer.parseInt(s1); if (start_port_range<1 || start_port_range>2*Short.MAX_VALUE) start_port_range=0;
				String s2 = s.substring(i+1); s2=s2.trim(); end_port_range = Integer.parseInt(s2); if (end_port_range<1 || end_port_range>2*Short.MAX_VALUE) end_port_range=0;
				return;
			}
			int j = s.indexOf(','); // list
			if (j!=-1) {
				String[] list = s.split(","); 
				if (list.length>1) {
					port_list = new int[list.length];
					for (int k=0; k<list.length; k++) {
						int t = Integer.parseInt(list[k]);
						if (t>1 && t<2*Short.MAX_VALUE) port_list[k] = t; 
					}
				}
				return;
			}
			// just number
			int t = Integer.parseInt(s);
			if (t>1 && t<2*Short.MAX_VALUE) port = t; 
		}
		public String get() {
			if (port!=0) return port+"";
			else if (port_list!=null) {
				StringBuffer sb = new StringBuffer();
				for (int i=0; i<port_list.length; i++) {
					sb.append(port_list[i]+",");
				}
				sb.deleteCharAt(sb.length()-1);
				return sb.toString();
			} 
			else return start_port_range+"-"+end_port_range;
		}
		public boolean match(int given_port) {
			if (port!=0) return (port==given_port);
			else if (port_list!=null) {
				for (int i=0; i<port_list.length; i++) {
					if (port_list[i]==given_port) return true;
				}
				return false;
			} 
			else return (start_port_range <= given_port && given_port <= end_port_range);
		}
	}
	
	class AddrDef {
		private long ip;
		private long mask;
		private PrefixFile prefix_file;
		public void set(String s) {
			int j = s.indexOf("prefix-file");
			if (j!=-1) {
				String p_label = s.substring(j+12);
				int id = safeParseInt(p_label);
				PrefixFile pf = null;
				if (id!=0) {
					for (PrefixFile tmp : policy.prefixfile_v) if (tmp.id==id) { pf=tmp; break; }
				} else {
					for (PrefixFile tmp : policy.prefixfile_v) if (tmp.name.equals(p_label)) { pf=tmp; break; }
				}
				prefix_file=pf;
				return;
			} 
			j = s.indexOf('/');
			if (j!=-1) { // subnet/mask or something similar
				String t = s.substring(j+1);
				ip = Utils.stringToLong(s.substring(0, j));
				if (t.indexOf('.')!=-1)	mask = Utils.stringToLong(t);
				else {
					j = Integer.parseInt(t);
					mask = (-1) << (32 - (j)); if (j==0) mask=0;
					// System.err.println("j="+j+", mask="+mask+", txtmask="+BillingEngine.longToIp(mask)+", t="+t);
				}
				ip = ip & mask; // adjust IP
				return;
			}
			ip = Utils.stringToLong(s);
			mask = -1;
		}
		public String get() {
			if (prefix_file!=null) return "prefix-file "+(prefix_file.id==0?prefix_file.name:prefix_file.id);
			else {
				String s="";
				if (mask!=-1) s = "/"+(32-Long.numberOfTrailingZeros(mask));
				return Utils.longToString(ip)+s;
			}
		}
		public boolean match(long given_ip) {
			if (prefix_file!=null) return prefix_file.match(given_ip);
			else if (ip==(given_ip & mask)) return true;
			else return false;
		}
	}

	class PrefixFile extends Elem {
		private String prefix_file_name;
		private int reload;
		private PrefixTree tree;
		public String dump() {
			//return "id="+id+", filename="+prefix_file_name+", prefixes="+tree.dump()+", reload="+reload;
			return "id="+id+", name="+name+", filename="+prefix_file_name+", prefixes="+tree.getNumberOfPrefixes()+", reload="+reload;
		}
		public void check() {
			tree.check();
		}

		public void init(Database db) {
			tree = new PrefixTree();
			String prefix_file_x = prefix_file_name;
			if (prefix_file_x.indexOf('/')==-1 && prefix_file_x.indexOf('\\')==-1) { // not a full path, adjust
				String xmlmapdirectory = db.getProperties().getProperty("db.cfg.path", "db");
				prefix_file_x = xmlmapdirectory+"/"+prefix_file_x;
			}
			tree.load(prefix_file_x);
		}

		public boolean match(long givenIp) {
			String res = tree.match(givenIp);
			if (res!=null) {
				//logger.debug("addr IP="+BillingEngine.longToIp(givenIp)+" matched prefix "+res);
				return true;
			} else return false;
			//return tree.match(givenIp)!=null? true:false; // ignore tags 
		}
	}
	
	class DateTime extends Elem {
		public DayType daytype;
		private Database db;
		private int cached_day=-1;
		private boolean cached_result;
		public DateTime(Database db) {
			this.db=db;
		}
		// TODO: daytype, time_period 
		public String dump() {
			return "id="+id+", name="+name+", daytype="+(daytype==null?"any":daytype.name());
		}
		public boolean match(){
			if (daytype==null) return true;
			int now_day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
			if (now_day!=cached_day) {
				cached_day = now_day;
				cached_result = false;
				DayType dt = db.getDayType();
				if (daytype.equals(dt)) cached_result=true;
				else if (daytype.equals(DayType.NONWORKINGDAY) && 
						(dt.equals(DayType.HOLIDAY) || dt.equals(DayType.WEEKEND)))	cached_result=true;
			}
			return cached_result;
		}
	}
	
	abstract class Elem {
		int id;
		String name;
		public Elem() { name=""; id=0; }
	}

	//###################################################################################
	// top-level class hosting all policy elements
	class Policy {
		Vector<Rule> rule_v;
		Vector<Condition> condition_v;
		Vector<Accounting> accounting_v;
		Vector<PrefixFile> prefixfile_v;
		Vector<DateTime> datetime_v;
		
		public Policy(){
			rule_v = new Vector<Rule>();
			condition_v = new Vector<Condition>();
			accounting_v = new Vector<Accounting>();
			prefixfile_v = new Vector<PrefixFile>();
			datetime_v = new Vector<DateTime>();
		}

		private Condition getCondition(String s) {
			int j = safeParseInt(s);
			Condition cc=null;
			if (j!=0) for (Condition c : policy.condition_v) { if (c.id==j) { cc=c; break; } }
			else for (Condition c : policy.condition_v) { if (c.name.equals(s)) { cc=c; break; } }
			return cc;
		}

		public String dump() {
			StringBuffer out = new StringBuffer();
			//out.append("\tDumping policy...\n");
			for (PrefixFile pf : prefixfile_v) out.append("\tPrefixFile: ["+pf.dump()+"]\n"); 
			for (DateTime pf : datetime_v) out.append("\tDateTime: ["+pf.dump()+"]\n"); 
			for (Condition pf : condition_v) out.append("\tCondition: ["+pf.dump()+"]\n"); 
			for (Accounting pf : accounting_v) out.append("\tAccounting: ["+pf.dump()+"]\n"); 
			for (Rule pf : rule_v) out.append("\tRule: ["+pf.dump()+"]\n"); 
			//out.append("\t... done dumping policy.\n");
			return out.toString();
		}
	}

	//###################################################################################
	// parser classes
	static class section {
		String name;
		int id=0;
		String id_name=null;
		Vector<String> elements;
		Vector<section> inner;
		
		public static String[] splitElement(String s) {
			String[] r = new String[2];
			String[] tmp = s.split(":");
			r[0] = tmp[0].trim();
			r[1] = tmp[1].trim();
			return r;
		}
		public static Vector<section> parse(ConfigBuffer cfgBuffer) {
			Vector<section> res = new Vector<section>();
			while ((cfgBuffer.getNext())!=null){
				cfgBuffer.pushBack();
				res.add(parseSection(cfgBuffer));
			}
			return res;
		}

		public String dump() {
			String e=""; for (String ee : elements) e=e+"{"+ee+"} ";
			String s=""; for (section ee : inner) s=s+"{"+ee.dump()+"} ";
			return "NAME="+name+", id="+id+", id_name="+id_name+", elements=["+e+"], subsections=["+s+"]";
		}

		private static section parseSection(ConfigBuffer cfgBuffer) {
			section tmp=null;
			String line;
			while ((line=cfgBuffer.getNext())!=null){
				int ob_pos=line.indexOf('{');
				if (ob_pos!=-1 && tmp!=null) {
					cfgBuffer.pushBack();
					tmp.inner.add(parseSection(cfgBuffer));
					continue;
				}
				else if (ob_pos!=-1 && tmp==null) {
					String[] header = line.split("\\s+", 3);
					tmp = new section();
					tmp.elements = new Vector<String>();
					tmp.inner = new Vector<section>();
					tmp.name = header[0];
					tmp.id = safeParseInt(header[1]); 
					if (tmp.id==0) tmp.id_name=header[1];
					continue;
				}
				
				int cb_pos=line.indexOf('}');
				if (cb_pos!=-1 && tmp!=null) {
					return tmp;
				}
				if (tmp!=null) 
					tmp.elements.add(line);
			}
			return tmp;
		}

	}

	class ConfigBuffer {
		private Vector<String> buf;
		private int position;
		public ConfigBuffer(){
			position=0;
			buf = new Vector<String>();
		}
		public void add(String x){
			buf.add(x);
		}
		public String getNext(){
			if (position>=buf.size()) return null;
			else {
				position++;
				return buf.elementAt(position-1);
			}
		}
		public void pushBack(){ position--;}

	}
	//###################################################################################
}
