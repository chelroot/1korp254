package com.netams.netams4.tariff;

import java.util.Collection;
import java.util.Vector;

import com.netams.netams4.types.obj4_service;
import com.netams.netams4.types.obj4_unidata;

// basic interface to indicate that this service-specific data is a VPN service, so we can pass some data to RADIUS 
public interface VPNService {

	public Vector<obj4_unidata> getVPNParameters(obj4_service service);

}

