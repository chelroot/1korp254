/*************************************************************************
*** This is NeTAMS, version 4
***	(c) 1998-2002 Anton Vinokurov <anton@netams.com>
***	(c) 2002-2008 NeTAMS Development Team
***	(c) 2008-2009 NETAMS LLC
***	All rights reserved. See 'Copying' file included in distribution
***	For latest version and more info, visit this project web page
***	located at http://www.netams.com
***
*************************************************************************/
/* $Id: PeriodicFeeIncludedVolume.java 1362 2012-02-19 16:35:25Z anton $ */


package com.netams.netams4.tariff;

import java.sql.Date;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.netams.netams4.AlarmEventManager;
import com.netams.netams4.BillingEngine;
import com.netams.netams4.datasource.DsAccountingInfo;
import com.netams.netams4.datasource.DsDataType;
import com.netams.netams4.datasource.DsMatchResult;
import com.netams.netams4.structures.*;
import com.netams.netams4.tariff.PolicyBasedEngine.ServiceSpecific;
import com.netams.netams4.types.*;

public final class PeriodicFeeIncludedVolume extends PeriodicFeeBase {

	private double price_up;
	private double price_down;
	private double included_up;
	private double included_down;
	private double fee;
	private boolean charge_policy_immediately;
	private boolean volume_adjust_proportional;
	private int period_multiplier;
	
	private static Logger logger = Logger.getLogger(PeriodicFeeIncludedVolume.class);
	
	public class PFIVSpecific extends specific {
		private static final long serialVersionUID = 1188876660318761L;
		// standard items to go for utilization table
		private long traffic_in=0;
		private long traffic_out=0;
		private double cost_in;
		private double cost_out;
		// copied from persistent items
		private obj4_unidata p_vleft_in, p_vleft_out; 	// left (unused) volume for this effective period:
														// mod_name = "p_vleft_*", mod_key = period_start (long), 
														// attribute_value = unused bytes (long)
		
		public PFIVSpecific(obj4_service me){
			if (me.persistent==null) {
				// that should never happen
				logger.error("Create PFIVSpecific called when no persistent info attached to service!");
				return;
			}
			for (obj4_unidata t : me.persistent) {
				if (t.getMod_name().equals("p_vleft_in"))  p_vleft_in = t; 
				if (t.getMod_name().equals("p_vleft_out")) p_vleft_out = t; 
			}
			if (p_vleft_in==null || p_vleft_out==null) logger.error("Create PFIVSpecific called but no right persistent found!");
			else { // replace (maybe improperly) stored persistent with ours 
				me.persistent.clear();
				me.persistent.add(p_vleft_in);
				me.persistent.add(p_vleft_out);
			}
		}

		public synchronized double update(obj4_account ac, long t_in, long t_out) {
			double cost_delta=0;
			if (t_in>0) {
				traffic_in += t_in;
				long unused_in = Long.parseLong(p_vleft_in.getAttribute_value());
				unused_in-=t_in;
				if (unused_in<0) { // oversubscription
					cost_delta = -((double)-unused_in* price_down)/volume_multiplier_int;
					cost_in += cost_delta; 
					unused_in=0;
				}
				p_vleft_in.setAttribute_value(Long.toString(unused_in));
			} 
			if (t_out>0) {
				traffic_out += t_out;
				long unused_out = Long.parseLong(p_vleft_out.getAttribute_value());
				unused_out-=t_out;
				if (unused_out<0) { // oversubscription
					cost_delta = -((double)-unused_out* price_up)/volume_multiplier_int;
					cost_out += cost_delta; 
					unused_out=0;
				}
				p_vleft_out.setAttribute_value(Long.toString(unused_out));
			}
			if (cost_delta!=0){ 
					synchronized (ac) {
						double c = ac.getBalance();
						c+=cost_delta;
						ac.setBalance(c);
					}
			}
			is_dirty=true;
			return cost_delta;
		}
		
		public synchronized void clear(){
			traffic_in=0;
			traffic_out=0;
			cost_in=0;
			cost_out=0;
			is_dirty=false;
		}

	}

	public PeriodicFeeIncludedVolume(){
		parameters.add(new ss_tariff(
			"Currency", 
			"Default tariff plan billing currency", 
			"currency", "1", ss_tariff.paramtype.INTEGER, null));
		parameters.add(new ss_tariff(
			"Periodicity", 
			"How often we have to charge periodic fee, String", 
			"period", "Monthly", ss_tariff.paramtype.SELECT, new String[] {"Yearly", "Monthly", "Daily", "Hourly"} ));
		parameters.add(new ss_tariff(
			"Period multiplier", 
			"How many periods (above) are in tariff cycle", 
			"period_multiplier", "1", ss_tariff.paramtype.INTEGER, null));
		parameters.add(new ss_tariff(
			"Periodic fee", 
			"Fee charged every given period", 
			"fee", "0", ss_tariff.paramtype.DOUBLE, null));
		parameters.add(new ss_tariff(
			"Multiplier string", 
			"Volume rate multiplier, String", 
			"vol_str", "Mbytes", ss_tariff.paramtype.SELECT, new String[] {"Bytes", "Kbytes", "Mbytes", "Gbytes"} ));
		parameters.add(new ss_tariff(
			"Included upload", 
			"Included amount of upload traffic, per multiplier", 
			"included_up", "0", ss_tariff.paramtype.DOUBLE, null ));
		parameters.add(new ss_tariff(
			"Included download", 
			"Included amount of download traffic, per multiplier", 
			"included_down", "0", ss_tariff.paramtype.DOUBLE, null ));
		parameters.add(new ss_tariff(
			"Upload price", 
			"Price for upload of traffic, per currency unit*multiplier", 
			"price_up", "0", ss_tariff.paramtype.DOUBLE, null ));
		parameters.add(new ss_tariff(
			"Download price", 
			"Price for download of traffic, per currency unit*multiplier", 
			"price_down", "0", ss_tariff.paramtype.DOUBLE, null ));
		parameters.add(new ss_tariff(
			"Charge policy", 
			"Periodic fee charge policy", 
			"charge_policy", "Immediately", ss_tariff.paramtype.SELECT, new String[] {"Immediately", "Period begins"} ));
		parameters.add(new ss_tariff(
			"Included adjustment", 
			"Included volume adjustment policy ", 
			"volume_adjust", "Proportional", ss_tariff.paramtype.SELECT, new String[] {"Proportional", "All"} ));
		
	}

	@Override
	public int add_acctunit(obj4_acctunit unit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public AuthInfoState add_funds(obj4_service me, obj4_account ac) {
		try {
			if (ac.getBalance()>=0  && me.getBlocked_by_admin()==0 && me.getBlocked_by_user()==0 && me.getWhen_deleted()==0) {
			logger.info("PeriodicFeeIncludedVolume account updated, check if we should charge fee (service="+me.getId()+")");
			PFIVSpecific fvs = (PFIVSpecific) me.getSp();
			long given_tp = Utils.safeParseLong(fvs.p_vleft_in.getMod_key(), 0);
			if (this_tariff_period>given_tp)
				if (charge_periodic_fee(me, ac, this_tariff_period)!=0) return AuthInfoState.BLOCK;
			}
		} catch (Exception e) {
			logger.debug("=== PFIV add_funds exception: se="+me.getId()+", ac="+ac.getId()+", fvs=["+me.getSp().dump()+"] ===");
			logger.debug(e.getMessage()); 
			}
		return AuthInfoState.PERMIT;
	}
	
	@Override
	public AuthInfoState service_action(Event.event_type action, obj4_service me, obj4_service oldS, obj4_account ac) {
		if (action == Event.event_type.SERVICE_DEL) return AuthInfoState.PERMIT;
		else if (action == Event.event_type.SERVICE_ADD) {
			if (currency.getId()!=ac.getCurrency_id()) {
				logger.info("PeriodicFeeIncludedVolume service addition failed: account currency differs from tariff plan currency (service="+me.getId()+").");
				return AuthInfoState.BLOCK;
			}
			
			logger.info("PeriodicFeeIncludedVolume create persistent (service="+me.getId()+")");
			me.persistent = new Vector <obj4_unidata>(2);
			obj4_unidata p_vleft_in = new obj4_unidata(); p_vleft_in.setMod_name("p_vleft_in"); me.persistent.add(p_vleft_in);
			obj4_unidata p_vleft_out = new obj4_unidata(); p_vleft_out.setMod_name("p_vleft_out"); me.persistent.add(p_vleft_out);
			PFIVSpecific fvs = new PFIVSpecific(me); 
			me.setSp(fvs);
	
		}
		// ADD or MOD
		if (charge_periodic_fee(me, ac, get_absolute_tariff_period())!=0) return AuthInfoState.BLOCK;
		else return AuthInfoState.PERMIT;
	}

	@Override
	public AuthInfoState ds_accounting(obj4_acctunit au, obj4_service s, obj4_account ac,	DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		if (ac==null) return null; // strange: where to charge from?
		
		long octets = dsItem.octets;
		double cost;
		PFIVSpecific fvs = (PFIVSpecific) s.getSp();
		//logger.info("PFIV ds_accounting (service="+s.getId()+", HC="+s.hashCode()+")"+", FVS="+fvs.hashCode());
		if (fvs == null) {
			logger.error("PFIV ds_accounting called but no specific info is initialized! (service="+s.getId()+", HC="+s.hashCode()+")");
			return AuthInfoState.BLOCK;
			}
		if (mr.getKey() == DsMatchResult.MATCH_SRC) {
			cost=fvs.update(ac, 0, octets);
		}
		else if (mr.getKey() == DsMatchResult.MATCH_DST) {
			cost=fvs.update(ac, octets, 0);
		}
		else if (mr.getKey() == DsMatchResult.MATCH_BOTH) {
			cost=fvs.update(ac, octets, octets);
		}
		else {
			logger.error("PFIV ds_accounting: SE="+s.getId()+", wrong match result: "+mr.getKey());
			return AuthInfoState.BLOCK;
		}
		
		// logger.info("PeriodicFeeIncludedVolume ds_accounting {"+mr+" octets="+octets+", cost="+cost+"}");
		if (s.getBlocked_by_billing()>0) return AuthInfoState.BLOCK; 
		else if (s.getBlocked_by_billing()==0){
			if (ac.getBalance()>0) return AuthInfoState.PERMIT;
			long u_in =  Long.parseLong(fvs.p_vleft_in.getAttribute_value());
			long u_out =  Long.parseLong(fvs.p_vleft_in.getAttribute_value());
			if (u_in + u_out >0) return AuthInfoState.PERMIT; // some unused included is left while balance is negative
			}
		return AuthInfoState.BLOCK;
	}

	@Override
	public AuthInfoState ds_authorizarion(obj4_acctunit au, obj4_service s, obj4_account ac, DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		// TODO Auto-generated method stub
		return AuthInfoState.PERMIT;
	}

	@Override
	public boolean init_service_runtime(obj4_service s, boolean at_start){
		if (s.persistent==null) {
			// init_service_runtime called when new service is added
			logger.info("PFIV init_service_runtime skip create service-specific (service="+s.getId()+")");
			// billing core calls add_service later
		} else {
			// init_service_runtime called when there is some persistent data, likely at billing startup
			PFIVSpecific fvs = new PFIVSpecific(s);
			s.setSp(fvs);
			if (!at_start) logger.info("PFIV init_service_runtime create service-specific (service="+s.getId()+", HC="+s.hashCode()+")"+", FVS="+fvs.hashCode());
		}
		return true; 
	}

	@Override
	public String getEngineDescription() {
		return "Charges periodic fee. Has some \"included traffic\" value and oversubscription flat rate price, separate for in/out direction.";
	}

	@Override
	public String getEngineName() {
		return "PeriodicFeeIncludedVolume";
	}

	@Override
	public int init(Database db) {
		
		localdatabase = db;
		is_customizable_per_service = false;
		volume_multiplier_int = 1024*1024; // TODO: make this values changeable via GUI
		volume_multiplier_str = "Mbytes"; // TODO: make this values changeable via GUI

		//default
		currency = db.cfg.Currency.values().iterator().next();
		price_up = 0;
		price_down = 0;
		included_up = 0;
		included_down = 0;
		fee = 0;
		period = Period.MONTH;
		charge_policy_immediately = true;
		volume_adjust_proportional = true;
		period_multiplier = 1;
		
		// specific
		for (obj4_unidata x: ourtariff.data) {
			if (x.getAttribute_name().equals("currency")) currency = db.cfg.Currency.getById(Integer.parseInt(x.getAttribute_value()));  
			if (x.getAttribute_name().equals("price_up")) price_up = Utils.parseDouble(x.getAttribute_value());  
			if (x.getAttribute_name().equals("price_down")) price_down = Utils.parseDouble(x.getAttribute_value());  
			if (x.getAttribute_name().equals("included_up")) included_up = Utils.parseDouble(x.getAttribute_value());  
			if (x.getAttribute_name().equals("included_down")) included_down = Utils.parseDouble(x.getAttribute_value());  
			if (x.getAttribute_name().equals("fee")) fee = Utils.parseDouble(x.getAttribute_value());  
			if (x.getAttribute_name().equals("period")) {
				String s = x.getAttribute_value();
				if (s.toLowerCase().equals("hourly")) period = Period.HOUR;
				else if (s.toLowerCase().equals("daily")) period = Period.DAY;
				else if (s.toLowerCase().equals("monthly")) period = Period.MONTH;
				else if (s.toLowerCase().equals("yearly")) period = Period.YEAR;
			}
			if (x.getAttribute_name().equals("period_multiplier")) period_multiplier = Utils.safeParseInt(x.getAttribute_value(), 1);  
			if (x.getAttribute_name().equals("charge_policy")) { 
				if (x.getAttribute_value().toLowerCase().equals("Immediately")) charge_policy_immediately=true; // period starts that moment
				else charge_policy_immediately=false; // period starts first second of period_spec
			}
			if (x.getAttribute_name().equals("volume_adjust")) { 
				if (x.getAttribute_value().toLowerCase().equals("Proportional")) volume_adjust_proportional=true; // divide periodic fee to volume of already passed time
				else volume_adjust_proportional=false; // always charge full periodic fee
			}
		}

		is_initialized=true;
		this_tariff_period = get_absolute_tariff_period();
		return 1;
	}

	@Override
	public boolean isCapable(DsAccountingInfo data) {
		if (data.type == DsDataType.NETFLOW5) return true;
		else if (data.type == DsDataType.PCAP) return true;
		else if (data.type == DsDataType.RAGENT) return true;
		else if (data.type == DsDataType.SNMP) return true;
		else if (data.type == DsDataType.RADIUS) return true;
		return false;
	}

	@Override
	public int remove_acctunit(obj4_acctunit unit) {
		// don't care
		return 0;
	}

	@Override
	public Vector<obj4> sync_specific(obj4_service se) {
		PFIVSpecific fvs = (PFIVSpecific) se.getSp();
		Vector<obj4> data = new Vector<obj4>(2);
		
		if (!(fvs.traffic_in==0 && fvs.cost_in==0)) {
			obj4_utilization ou_in = new obj4_utilization();
			ou_in.setService_id(se.getId());
			ou_in.setService_key("traffic-in");
			ou_in.setService_volume(fvs.traffic_in);
			ou_in.setCost(-fvs.cost_in);
			data.add(ou_in);
		}

		if (!(fvs.traffic_out==0 && fvs.cost_out==0)) {
			obj4_utilization ou_out = new obj4_utilization();
			ou_out.setService_id(se.getId());
			ou_out.setService_key("traffic-out");
			ou_out.setService_volume(fvs.traffic_out);
			ou_out.setCost(-fvs.cost_out);
			data.add(ou_out);
		}
		
		fvs.clear();
		return data;
	}

	@Override
	public int timer_event(Database db, Event evt) {
		// TODO deal with period change
		long now_tp = get_absolute_tariff_period();
		// logger.debug("PFIV timer: tariff="+ourtariff.getId()+", evt="+evt.when+", now_tp="+now_tp+", this_tp="+this_tariff_period);
		if (this_tariff_period == now_tp && !is_first_timer_loop) return 0; // nothing to do
		else {
			// tariff period went up: need to charge periodic && update persistent data
			logger.debug("PFIV charge: tariff="+ourtariff.getId()+", old_tp="+this_tariff_period+", new_tp="+now_tp);
			for (obj4_service se : db.cfg.Service.values()) {
				if (se.getTariff_id() == this.ourtariff.getId() && se.getBlocked_by_admin()==0 &&se.getBlocked_by_user()==0 && se.getWhen_deleted()==0) {
					obj4_account ac=null;
					for (obj4_account a : db.cfg.Account.values()) if (a.getId() == se.getAccount_id()) { ac=a; break; }
					if (ac!=null) {
						if (charge_periodic_fee(se, ac, now_tp)==0) {
							db.map_billing.billing_process_ais(se, AuthInfoState.PERMIT, null, now_tp); // success: unblock
						}
						else {
							db.map_billing.billing_process_ais(se, AuthInfoState.BLOCK, null, now_tp); // fail: block 
						}
					}
					else logger.info("PeriodicFeeIncludedVolume auto charge fee failed: no associated account, se="+se.getId());
				}
			}
			
			this_tariff_period = now_tp;
			is_first_timer_loop = false;
		}
		return 0;
	}

	private int charge_periodic_fee(obj4_service se, obj4_account ac, long now_tp) {
		double charged_fee;
		double proportion=1;
		if  (se.getBlocked_by_admin()!=0 || se.getBlocked_by_user()!=0 || se.getWhen_deleted()!=0) return 0; // we don't charge from blocked services 
		if (volume_adjust_proportional==true) {
			proportion = get_proportion();
			charged_fee = fee*proportion;
		} else charged_fee = fee;
		
		PFIVSpecific fvs = (PFIVSpecific) se.getSp();
		long memorized_tp = Utils.safeParseLong(fvs.p_vleft_in.getMod_key(), 0); // TODO: set this_tariff_period to zero to trigger fee charge && unidata fillup at service addition
		int delta = get_tariff_period_delta(memorized_tp);

		logger.debug("SE="+se.getId()+", mem_tp="+memorized_tp+", prop="+proportion+", this_tp="+this_tariff_period+", delta="+delta+", now="+System.currentTimeMillis());
		if (delta==0) return 0; // likely we just started && service's tariff period not changed
		logger.info("PeriodicFeeIncludedVolume charge fee ["+charged_fee+"] (service="+se.getId()+") from (account="+ac.getId()+")");

		String this_tp = ""+now_tp;
		synchronized (ac) {
			if (charged_fee!=0 && charged_fee>ac.getBalance()) {
				logger.info("PeriodicFeeIncludedVolume charge fee failed: not enough funds.");
				// flush included volume for this period
				fvs.p_vleft_in.setAttribute_value("0");
				fvs.p_vleft_out.setAttribute_value("0");
				return -1;
			} else if ( (charged_fee!=0 && charged_fee<=ac.getBalance()) || (charged_fee==0) ){
				reliablyChargeFee(localdatabase, -charged_fee, se, ourtariff, now_tp);
				AlarmEventManager.submitEvent("periodic_fee", se.getAccount_id(), se.getHr_contract()!=null?se.getHr_contract():"CON-"+se.getContract_id(), "SERVICE_ID: "+se.getId()+", TARIFF: "+(se.getHr_tariff()!=null?se.getHr_tariff():this.ourtariff.getName())+", FEE: "+charged_fee+", PERIOD: "+DateFormat.getInstance().format(new Date(now_tp)));
			} 
		}
	
		logger.info("PeriodicFeeIncludedVolume update persistent (service="+se.getId()+", this_tp="+this_tp+")");
		fvs.p_vleft_out.setMod_key(this_tp);
		fvs.p_vleft_out.setAttribute_value(Long.toString((long)(included_up*volume_multiplier_int*proportion)));
		fvs.p_vleft_in.setMod_key(this_tp);
		fvs.p_vleft_in.setAttribute_value(Long.toString((long)(included_down*volume_multiplier_int*proportion)));
		return 0;
	}

	@Override
	public String dump() {
		return "Currency="+currency.getAbbreviation()+", price_up="+price_up+", price_down="+price_down+", this TP="+this_tariff_period;
	}

}
