/*************************************************************************
*** This is NETAMS, version 4
***	(c) 1998-2002 Anton Vinokurov <anton@netams.com>
***	(c) 2002-2008 NeTAMS Development Team
***	(c) 2008-2012 NETAMS LLC
***	All rights reserved. See 'Copying' file included in distribution
***	For latest version and more info, visit this project web page
***	located at http://www.netams.com
***
*************************************************************************/
/* $Id: PeriodicFeeIncludedVolume.java 1305 2012-01-25 19:54:53Z anton $ */


package com.netams.netams4.tariff;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.netams.netams4.AlarmEventManager;
import com.netams.netams4.datasource.DsAccountingInfo;
import com.netams.netams4.datasource.DsDataType;
import com.netams.netams4.datasource.DsMatchResult;
import com.netams.netams4.structures.*;
import com.netams.netams4.types.*;

public final class XPrepaidByDaysVPN1 extends PeriodicFeeBase implements VPNService {

	private static final String DEFAULT_CONFIG_FILE_NAME = "prepaidvpn.cfg";
	private String config_file;
	private int free_upload_speed;
	private int free_download_speed;
	private int paid_upload_speed;
	private int paid_download_speed;
	private int free_period;
	private boolean transfer_free_days;
	private boolean permit_multiple_logins;
	private TreeMap<Double, Integer> conversion_table;
	
	private static Logger logger = Logger.getLogger(XPrepaidByDaysVPN1.class);
	
	public class XPrepaidByDaysSpecific extends VPNServiceSpecific {
		private static final long serialVersionUID = 454767104538761L;
		// standard items to go for utilization table
		private long traffic_in=0;
		private long traffic_out=0;

		// copied from persistent items
		private obj4_unidata period_start; 	 // mod_name = "period_start", 
											 // mod_key = period_start (long),
											 // attribute_name = period end(long)	
											 // attribute_value = "free" | "paid" 	
		

		public XPrepaidByDaysSpecific(obj4_service me){
			if (me.persistent==null) {
				// that should never happen
				logger.error("Create XPrepaidByDaysSpecific called when no persistent info attached to service!");
				return;
			}
			for (obj4_unidata t : me.persistent) {
				if (t.getMod_name().equals("period_start"))  period_start = t; 
			}
			if (period_start==null ) logger.error("Create XPrepaidByDaysSpecific called but no right persistent found!");
		}

		public synchronized void update(long t_in, double c_in, long t_out, double c_out) {
			traffic_in += t_in;
			traffic_out += t_out;
			is_dirty=true;
		}

		public synchronized void clear(){
			traffic_in=0;
			traffic_out=0;
			is_dirty=false;
		}

		@Override
		public boolean getPermitMultipleLogins() { return permit_multiple_logins; }

	}

	public XPrepaidByDaysVPN1(){
		
		parameters.add(new ss_tariff(
			"Currency", 
			"Default tariff plan billing currency", 
			"currency", "1", ss_tariff.paramtype.INTEGER, null));
		parameters.add(new ss_tariff(
			"Conversion rate configuration file", 
			"Conversion rate file path relative to \"jserver/db/\" directory, or absolute, String", 
			"config_file", DEFAULT_CONFIG_FILE_NAME, ss_tariff.paramtype.STRING, null));
		parameters.add(new ss_tariff(
			"Free Upload speed", 
			"Free Upload speed, Kbits/s", 
			"free_upload_speed", "0", ss_tariff.paramtype.INTEGER, null ));
		parameters.add(new ss_tariff(
			"Free Download speed", 
			"Free Download speed, Kbits/s", 
			"free_download_speed", "0", ss_tariff.paramtype.INTEGER, null ));
		parameters.add(new ss_tariff(
			"Free period", 
			"Free service period, days", 
			"free_period", "14", ss_tariff.paramtype.INTEGER, null ));
		parameters.add(new ss_tariff(
			"Transfer free days", 
			"Transfer remaining unused free days upon paid, true/false", 
			"transfer_free_days", "false", ss_tariff.paramtype.SELECT, new String[] {"true", "false"} ));
		parameters.add(new ss_tariff(
			"Paid Upload speed", 
			"Paid Upload speed, Kbits/s", 
			"paid_upload_speed", "0", ss_tariff.paramtype.INTEGER, null ));
		parameters.add(new ss_tariff(
			"Paid Download speed", 
			"Paid Download speed, Kbits/s", 
			"paid_download_speed", "0", ss_tariff.paramtype.INTEGER, null ));
		parameters.add(new ss_tariff(
			"Permit multiple logins", 
			"Permit multiple simultaneous VPN service logins, true/false", 
			"permit_multiple_logins", "false", ss_tariff.paramtype.SELECT, new String[] {"true", "false"} ));
	}

	@Override
	public boolean init_service_runtime(obj4_service s, boolean at_start){
		if (s.persistent==null) {
			// init_service_runtime called when new service is added
			logger.info("XPrepaidByDaysVPN1 init_service_runtime skip create service-specific (service="+s.getId()+")");
			// billing core calls add_service later
		} else {
			// init_service_runtime called when there is some persistent data, likely at billing startup
			XPrepaidByDaysSpecific fvs = new XPrepaidByDaysSpecific(s);
			s.setSp(fvs);
			if (!at_start) logger.info("XPrepaidByDaysVPN1 init_service_runtime create service-specific (service="+s.getId()+", HC="+s.hashCode()+")"+", FVS="+fvs.hashCode());
			// logger.debug("XPrepaidByDaysVPN1 persistent for service "+s.getId());
			// for (obj4_unidata ud : s.persistent) logger.debug(ud.toString());
		}
		return true; 
	}

	@Override
	public String getEngineDescription() {
		return "Manages prepaid VPN service with specified free period, and pay later. Uses funds->days recalculation table from external file. Charges all balance to convert it onto remaining service days. VPN Rate-limit.";
	}

	@Override
	public String getEngineName() {
		return "XPrepaidByDaysVPN1";
	}

	@Override
	public int init(Database db) {
		
		localdatabase = db;
		is_customizable_per_service = false;
		volume_multiplier_int = 1024*1024; // TODO: make this values changeable via GUI
		volume_multiplier_str = "Mbytes"; // TODO: make this values changeable via GUI

		//default
		currency = db.cfg.Currency.values().iterator().next();
		config_file = DEFAULT_CONFIG_FILE_NAME;
		free_upload_speed=0;
		free_download_speed=0;
		paid_upload_speed=0;
		paid_download_speed=0;
		free_period=14;
		transfer_free_days=false;
		permit_multiple_logins=false;
		conversion_table = new TreeMap<Double, Integer>();
		conversion_table.put(0.0, 0);

		// specific
		for (obj4_unidata x: ourtariff.data) {
			if (x.getAttribute_name().equals("currency")) currency = db.cfg.Currency.getById(Integer.parseInt(x.getAttribute_value()));  
			if (x.getAttribute_name().equals("config_file")) config_file = x.getAttribute_value();  
			if (x.getAttribute_name().equals("free_upload_speed")) free_upload_speed = Utils.parseInt(x.getAttribute_value());  
			if (x.getAttribute_name().equals("free_download_speed"))  free_download_speed= Utils.parseInt(x.getAttribute_value());  
			if (x.getAttribute_name().equals("paid_upload_speed"))  paid_upload_speed = Utils.parseInt(x.getAttribute_value());  
			if (x.getAttribute_name().equals("paid_download_speed")) paid_download_speed = Utils.parseInt(x.getAttribute_value());  
			if (x.getAttribute_name().equals("free_period")) free_period = Utils.parseInt(x.getAttribute_value());  
			if (x.getAttribute_name().equals("transfer_free_days")) transfer_free_days = Boolean.parseBoolean(x.getAttribute_value());  
			if (x.getAttribute_name().equals("permit_multiple_logins")) permit_multiple_logins = Boolean.parseBoolean(x.getAttribute_value());  
		}
		if (free_period<0 || free_period>365) free_period=14; // safety
		loadConfig(db, config_file);
		logger.debug("XPrepaidByDaysVPN1 ["+ourtariff.getName()+"] conversion table loaded with "+conversion_table.size()+" items");
		is_initialized=true;
		return 1;
	}

	@Override
	public int add_acctunit(obj4_acctunit unit) {
		return 0; // don't care
	}

	@Override
	public AuthInfoState add_funds(obj4_service me, obj4_account ac) {
		try {
			if (ac.getBalance()>=0  && me.getBlocked_by_admin()==0 && me.getBlocked_by_user()==0 && me.getWhen_deleted()==0) {
			logger.info("XPrepaidByDaysVPN1 account updated, move all funds to days (service="+me.getId()+")");
			charge(me, ac); // move all money onto service's days
			}
		} catch (Exception e) {
			logger.debug("=== XPrepaidByDaysVPN1 add_funds exception: se="+me.getId()+", ac="+ac.getId()+", fvs=["+me.getSp().dump()+"] ===");
			logger.debug(e.getMessage()); 
			}
		return AuthInfoState.PERMIT;
	}
	
	@Override
	public AuthInfoState service_action(Event.event_type action, obj4_service me, obj4_service oldS, obj4_account ac) {
		if (action == Event.event_type.SERVICE_DEL) return AuthInfoState.BLOCK;
		else if (action == Event.event_type.SERVICE_ADD) {
			if (currency.getId()!=ac.getCurrency_id()) {
				logger.info("XPrepaidByDaysVPN1 service addition failed: account currency differs from tariff plan currency (service="+me.getId()+").");
				return AuthInfoState.BLOCK;
			}
			
			logger.info("XPrepaidByDaysVPN1 create persistent (service="+me.getId()+")");
			me.persistent = new Vector <obj4_unidata>(1);
			long t = System.currentTimeMillis();
			obj4_unidata period_start = new obj4_unidata(); 
			period_start.setMod_name("period_start");
			period_start.setMod_key(t+""); 
			period_start.setAttribute_name((t+(long)free_period*1000*24*60*60)+"");
			period_start.setAttribute_value("free");
			me.persistent.add(period_start);
			XPrepaidByDaysSpecific fvs = new XPrepaidByDaysSpecific(me); 
			me.setSp(fvs);
		}
		// ADD or MOD
		charge(me, ac); // move all money onto service's days
		return AuthInfoState.PERMIT;
	}

	@Override
	public AuthInfoState ds_accounting(obj4_acctunit au, obj4_service s, obj4_account ac, DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		if (ac==null) return null; // strange: where to charge from?
		
		long octets = dsItem.octets;
		XPrepaidByDaysSpecific fvs = (XPrepaidByDaysSpecific) s.getSp();
		//logger.info("XMVPN ds_accounting (service="+s.getId()+", HC="+s.hashCode()+")"+", FVS="+fvs.hashCode());
		if (fvs == null) {
			logger.error("XPrepaidByDaysVPN1 ds_accounting called but no specific info is initialized! (service="+s.getId()+", HC="+s.hashCode()+")");
			return AuthInfoState.BLOCK;
			}
		if (mr.getKey() == DsMatchResult.MATCH_SRC) fvs.update(0, 0, octets, 0);
		else if (mr.getKey() == DsMatchResult.MATCH_DST) fvs.update(octets, 0, 0, 0);
		else if (mr.getKey() == DsMatchResult.MATCH_BOTH) fvs.update(octets, 0, octets, 0);
		else {
			logger.error("XPrepaidByDaysVPN1 ds_accounting: SE="+s.getId()+", wrong match result: "+mr.getKey());
			return AuthInfoState.BLOCK;
		}
		if (s.getBlocked_by_billing()==0) return AuthInfoState.PERMIT;
		return AuthInfoState.BLOCK;
	}

	@Override
	public AuthInfoState ds_authorizarion(obj4_acctunit au, obj4_service s, obj4_account ac, DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		// TODO Auto-generated method stub
		return AuthInfoState.PERMIT;
	}

	
	@Override
	public boolean isCapable(DsAccountingInfo data) {
		if (data.type == DsDataType.RADIUS) return true;
		return false;
	}

	@Override
	public int remove_acctunit(obj4_acctunit unit) {
		// don't care
		return 0;
	}

	@Override
	public Vector<obj4> sync_specific(obj4_service se) {
		XPrepaidByDaysSpecific fvs = (XPrepaidByDaysSpecific) se.getSp();
		Vector<obj4> data = new Vector<obj4>(2);
		
		if (fvs.traffic_in!=0) {
			obj4_utilization ou_in = new obj4_utilization();
			ou_in.setService_id(se.getId());
			ou_in.setService_key("vpn-in");
			ou_in.setService_volume(fvs.traffic_in);
			ou_in.setCost(0);
			data.add(ou_in);
		}

		if (fvs.traffic_out!=0) {
			obj4_utilization ou_out = new obj4_utilization();
			ou_out.setService_id(se.getId());
			ou_out.setService_key("vpn-out");
			ou_out.setService_volume(fvs.traffic_out);
			ou_out.setCost(0);
			data.add(ou_out);
		}
		fvs.clear();
		return data;
	}

	@Override
	public int timer_event(Database db, Event evt) {
		// logger.debug("XPrepaidByDaysVPN1 charge: tariff="+ourtariff.getId()+", now="+evt.when);
		for (obj4_service se : db.cfg.Service.values()) {
			if (se.getTariff_id() == ourtariff.getId() && se.getBlocked_by_admin()==0 &&se.getBlocked_by_user()==0 && se.getWhen_deleted()==0) {
				XPrepaidByDaysSpecific fvs = (XPrepaidByDaysSpecific) se.getSp();
				long final_allowed = Utils.safeParseLong(fvs.period_start.getAttribute_name(), 0);
				if (final_allowed<evt.when && se.getBlocked_by_billing()==0) { // final limit passed, block it
					db.map_billing.billing_process_ais(se, AuthInfoState.BLOCK, null, evt.when); // fail: block 
				} else if (final_allowed>=evt.when && se.getBlocked_by_billing()!=0) { // why it is blocked?
					db.map_billing.billing_process_ais(se, AuthInfoState.PERMIT, null, evt.when); // unblock 
				}
			}
		}
		return 0;
	}

	private void charge(obj4_service se, obj4_account ac) {
		if  (se.getBlocked_by_admin()!=0 || se.getBlocked_by_user()!=0 || se.getWhen_deleted()!=0) return; // we don't charge from blocked services 
		if (ac.getBalance()<=0) return; // what we are trying to charge?? no funds there.
		
		XPrepaidByDaysSpecific fvs = (XPrepaidByDaysSpecific) se.getSp();
		long tp_start = Utils.safeParseLong(fvs.period_start.getMod_key(), 0); 
		long final_allowed = Utils.safeParseLong(fvs.period_start.getAttribute_name(), 0); 
		boolean period_free = "free".equals(fvs.period_start.getAttribute_value());
		long now = System.currentTimeMillis();
		
		logger.debug("SE="+se.getId()+", tp_this="+tp_start+", final_allowed="+final_allowed+", now="+now +", now-free="+period_free);

		long time_add = get_extension_period_for_money(ac.getBalance());
		int days_ext = (int)(time_add/(1000*24*60*60)); 
		
		logger.info("XPrepaidByDaysVPN1 convert ["+ac.getBalance()+"] funds to "+time_add+" msec, or "+days_ext+" days, (service="+se.getId()+") from (account="+ac.getId()+")");

		if (transfer_free_days && period_free && (final_allowed>now)) {
			long remaining = (final_allowed - now);
			//time_add +=remaining;
			days_ext = (int)(remaining/(1000*24*60*60));
			logger.info("XPrepaidByDaysVPN1 add free time: "+remaining+" msec, or "+days_ext+" days, (service="+se.getId()+")");
		}
		
		synchronized (ac) {
			if (period_free) fvs.period_start.setAttribute_value("paid");
			if (!transfer_free_days) final_allowed = tp_start; // reset
			long new_final_allowed = Math.max(final_allowed,now)+time_add; // add to already paid period, not just _now_
			fvs.period_start.setAttribute_name(new_final_allowed+"");
			reliablyChargeFee(localdatabase, -ac.getBalance(), se, ourtariff, now);
			AlarmEventManager.submitEvent("periodic_fee", se.getAccount_id(), se.getHr_contract()!=null?se.getHr_contract():"CON-"+se.getContract_id(), "SERVICE_ID: "+se.getId()+", TARIFF: "+(se.getHr_tariff()!=null?se.getHr_tariff():this.ourtariff.getName())+", DAYS: "+days_ext+", PERIOD: "+DateFormat.getInstance().format(new Date(new_final_allowed)));
			} 
	
		logger.info("XPrepaidByDaysVPN1 update persistent (service="+se.getId()+")");
		return;
	}

	private long get_extension_period_for_money(double balance) {
		Integer ed = conversion_table.get(balance);
		if (ed!=null) { // best match
			return ed.longValue()*24*60*60*1000;
		} else {
			double a1 = conversion_table.keySet().iterator().next(); // likely a1==0
			for (double b : conversion_table.keySet()) {
				logger.debug("get_extension_period_for_money["+balance+"] a1="+a1+", b="+b);
				if (a1<balance && balance<=b) {
					long ed1 = conversion_table.get(a1);
					long ed2 = conversion_table.get(b);
					return (long) (ed1*24*60*60*1000 + (((double)(ed2-ed1)*24*60*60*1000)/(b-a1))*(balance-a1));
				}
				a1=b;
			}
			long ed1 = conversion_table.get(a1);
			if (balance > a1) return (long)((double)ed1*24*60*60*1000*balance/a1);  
		}
		return 0; // shit happened
	}

	@Override
	public String dump() {
		return "Currency="+currency.getAbbreviation()+", free speed (Up/Down)="+free_upload_speed+"/"+free_download_speed+", paid speed (Up/Down)="+paid_upload_speed+"/"+paid_download_speed;
	}

	
	public Vector<obj4_unidata> getVPNParameters(obj4_service s) {
		Vector<obj4_unidata> res = new Vector<obj4_unidata>();
		obj4_unidata ud;

		XPrepaidByDaysSpecific fvs = (XPrepaidByDaysSpecific) s.getSp();
		long paid_until = Utils.safeParseLong(fvs.period_start.getAttribute_name(), 0);
		boolean period_free = "free".equals(fvs.period_start.getAttribute_value());
		long now = System.currentTimeMillis();
		//logger.debug("service="+s+", tm_next="+tm_next+", now="+now);
		if (paid_until > now) {
			ud = new obj4_unidata();
			ud.setMod_key("session_timeout"); 
			ud.setAttribute_name("integer"); 
			ud.setAttribute_value((paid_until - now)/1000+"");
			res.add(ud);
		}
		
		ud = new obj4_unidata();
		ud.setMod_key("upload_rate"); 
		ud.setMod_name("Upload rate"); 
		ud.setAttribute_name("integer"); 
		if (period_free) ud.setAttribute_value(free_upload_speed+""); else ud.setAttribute_value(paid_upload_speed+"");  
		res.add(ud);

		ud = new obj4_unidata();
		ud.setMod_key("download_rate"); 
		ud.setMod_name("Download rate"); 
		ud.setAttribute_name("integer"); 
		if (period_free) ud.setAttribute_value(free_download_speed+""); else ud.setAttribute_value(paid_download_speed+"");  
		res.add(ud);

		return res;
	}
	
	private boolean loadConfig(Database db, String filename1) {
		String config_file_x = filename1;
		if (config_file_x.indexOf('/')==-1 && config_file_x.indexOf('\\')==-1) { // not a full path, adjust
			String xmlmapdirectory = db.getProperties().getProperty("db.cfg.path", "db");
			config_file_x = xmlmapdirectory+"/"+config_file_x;
		}
		try {
			BufferedReader r = new BufferedReader(new FileReader(config_file_x));
			while (r.ready()) {
				String s = r.readLine();
				if (s!=null )s=s.trim();
				if (s==null || s.equals("\n") || s.isEmpty() || s.indexOf('#')==0) continue; // comments and empty lines
				int j=s.indexOf('#'); if (j>0) s = s.substring(0,j); // trailing comments
				s = s.replaceAll("\t", " ");
				String ss[] = s.split("\\s+");
				double fee = Utils.safeParseDouble(ss[0], 0);
				int days = Utils.safeParseInt(ss[1], 0);
				if (fee!=0 && days!=0) conversion_table.put(fee, days);
			}
		} catch (FileNotFoundException x) {
			ExceptionManager.handleError("Specified configuration file, \""+config_file+"\", is not found.", x);
			return false;
		} catch (IOException x) {
			ExceptionManager.handleError("I/O error while reading configuration file, \""+config_file+"\".", x);
			return false;
		}
		return true;
	}

}
