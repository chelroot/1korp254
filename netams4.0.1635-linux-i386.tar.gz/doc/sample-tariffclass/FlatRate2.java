/*************************************************************************
*** This is NeTAMS, version 4
***	(c) 1998-2002 Anton Vinokurov <anton@netams.com>
***	(c) 2002-2008 NeTAMS Development Team
***	(c) 2008-2009 NETAMS LLC
***	All rights reserved. See 'Copying' file included in distribution
***	For latest version and more info, visit this project web page
***	located at http://www.netams.com
***
*************************************************************************/
/* $Id: FlatRate2.java 1431 2012-06-17 16:30:07Z anton $ */


package com.netams.netams4.tariff;

import java.util.Vector;

import org.apache.log4j.Logger;

import com.netams.netams4.BillingEngine;
import com.netams.netams4.datasource.DsAccountingInfo;
import com.netams.netams4.datasource.DsDataType;
import com.netams.netams4.datasource.DsMatchResult;
import com.netams.netams4.structures.*;
import com.netams.netams4.types.*;

public final class FlatRate2 extends TariffEngine {


	private double price_up=0; 
	private double price_down=0;

	public static class ServiceSpecific extends specific {
		private static final long serialVersionUID = 6886380666100318761L;
		private long traffic_in=0;
		private long traffic_out=0;
		private double cost_in;
		private double cost_out;
				
		public synchronized void update(long t_in, double c_in, long t_out, double c_out) {
			traffic_in += t_in;
			cost_in += c_in;
			traffic_out += t_out;
			cost_out += c_out;
			is_dirty=true;
		}
		public synchronized void balance(obj4_account ac, double cost) {
			synchronized (ac) {
				double c = ac.getBalance();
				c+=cost;
				ac.setBalance(c);
			}
		}
		
		public synchronized void clear(){
			traffic_in=0;
			traffic_out=0;
			cost_in=0;
			cost_out=0;
			is_dirty=false;
		}
	}

	public FlatRate2(){
		parameters.add(new ss_tariff(
			"Currency", 
			"Default tariff plan billing currency", 
			"currency", "1", ss_tariff.paramtype.INTEGER, null));
		parameters.add(new ss_tariff(
			"Multiplier string", 
			"Volume rate multiplier, String", 
			"vol_str", "Mbytes", ss_tariff.paramtype.SELECT, new String[] {"Bytes", "Kbytes", "Mbytes", "Gbytes"} ));
		parameters.add(new ss_tariff(
			"Upload price", 
			"Price for upload of traffic, per currency unit*multiplier", 
			"price_up", "0", ss_tariff.paramtype.DOUBLE, null ));
		parameters.add(new ss_tariff(
			"Download price", 
			"Price for download of traffic, per currency unit*multiplier", 
			"price_down", "0", ss_tariff.paramtype.DOUBLE, null ));
		
	}

	@Override
	public int add_acctunit(obj4_acctunit unit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public AuthInfoState service_action(Event.event_type action, obj4_service newS, obj4_service oldS, obj4_account ac) {
		if (action==Event.event_type.SERVICE_ADD || action==Event.event_type.SERVICE_MOD) return add_funds(newS, ac);
		else return AuthInfoState.PERMIT;
	}

	@Override
	public AuthInfoState ds_accounting(obj4_acctunit au, obj4_service s, obj4_account ac,	DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		if (ac==null) return null; // strange: where to charge from?
		long octets = dsItem.octets;
		double costu = -octets * price_up/volume_multiplier_int;
		double costd = -octets * price_down/volume_multiplier_int;
		double cost;
		ServiceSpecific fvs = (ServiceSpecific) s.getSp();
		if (fvs == null) {
			Logger.getLogger(FlatRate2.class).error("FlatRate2 ds_accounting called but no specific info is initialized! (service="+s.getId()+")");
			return null;
			}
		if (mr.getKey() == DsMatchResult.MATCH_SRC) {
			cost=costu;
			fvs.balance(ac, costu);
			fvs.update(0, 0, octets, costu);
		}
		else if (mr.getKey() == DsMatchResult.MATCH_DST) {
			cost=costd;
			fvs.balance(ac, costd);
			fvs.update(octets, costd, 0, 0);
		}
		else if (mr.getKey() == DsMatchResult.MATCH_BOTH) {
			cost=costd+costu;
			fvs.balance(ac, cost);
			fvs.update(octets, costd, octets, costu);
		}
		else return null;
		// Logger.getLogger(FlatRate2.class).info("FlatRate2 ds_accounting {"+mr+" octets="+octets+", cost="+cost+"}");
		return add_funds(s, ac); // decision is based on current balance only
	}

	@Override
	public AuthInfoState ds_authorizarion(obj4_acctunit au, obj4_service s, obj4_account ac, DsAccountingInfo dsItem, DsMatchResult mr, TagSet tt) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean init_service_runtime(obj4_service s, boolean at_start){
		ServiceSpecific fvs = (ServiceSpecific) s.getSp();
		if (fvs == null) {
			if (!at_start) Logger.getLogger(FlatRate2.class).info("FlatRate2 init_service_runtime create service-specific (service="+s.getId()+")");
			fvs = new ServiceSpecific();
			s.setSp(fvs);
			return true;
		} 
		return false;
	}

	@Override
	public String getEngineDescription() {
		return "Flat Rate billing engine version 2, charges plain utilization with rate per megabyte (separate values for in/out)";
	}

	@Override
	public String getEngineName() {
		return "Flat Rate v2";
	}

	@Override
	public int init(Database db) {
		
		is_customizable_per_service = false;
		volume_multiplier_int = 1024*1024; // TODO: make this values changeable via GUI
		volume_multiplier_str = "Mbytes"; // TODO: make this values changeable via GUI

		//default
		currency = db.cfg.Currency.values().iterator().next();
		price_up = 0;
		price_down = 0;
		
		// specific
		for (obj4_unidata x: ourtariff.data) {
			if (x.getAttribute_name().equals("currency")) currency = db.cfg.Currency.getById(Integer.parseInt(x.getAttribute_value()));  
			if (x.getAttribute_name().equals("price_up")) price_up = Utils.parseDouble(x.getAttribute_value());  
			if (x.getAttribute_name().equals("price_down")) price_down = Utils.parseDouble(x.getAttribute_value());  
		}
		
		is_initialized=true;
		return 1;
	}

	@Override
	public boolean isCapable(DsAccountingInfo data) {
		if (data.type == DsDataType.NETFLOW5) return true;
		else if (data.type == DsDataType.PCAP) return true;
		else if (data.type == DsDataType.RAGENT) return true;
		else if (data.type == DsDataType.SNMP) return true;
		else if (data.type == DsDataType.RADIUS) return true;
		return false;
	}

	@Override
	public int remove_acctunit(obj4_acctunit unit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Vector<obj4> sync_specific(obj4_service se) {
		ServiceSpecific fvs = (ServiceSpecific) se.getSp();
		Vector<obj4> data = new Vector<obj4>(2);
		
		if (!(fvs.traffic_in==0 && fvs.cost_in==0)) {
			obj4_utilization ou_in = new obj4_utilization();
			ou_in.setService_id(se.getId());
			ou_in.setService_key("traffic-in");
			ou_in.setService_volume(fvs.traffic_in);
			ou_in.setCost(-fvs.cost_in);
			data.add(ou_in);
		}

		if (!(fvs.traffic_out==0 && fvs.cost_out==0)) {
			obj4_utilization ou_out = new obj4_utilization();
			ou_out.setService_id(se.getId());
			ou_out.setService_key("traffic-out");
			ou_out.setService_volume(fvs.traffic_out);
			ou_out.setCost(-fvs.cost_out);
			data.add(ou_out);
		}
		
		fvs.clear();
		return data;
	}

	@Override
	public int timer_event(Database db, Event evt) {
		// Logger.getLogger(FlatRate2.class).info("FlatRate2 timer_event {"+new Date(evt.when)+"}");
		return 0;
	}

	@Override
	public String dump() {
		return "Currency="+currency.getAbbreviation()+", price_up="+price_up+", price_down="+price_down;
	}

}
