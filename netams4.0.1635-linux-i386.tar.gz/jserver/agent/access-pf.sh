#!/bin/sh

# WARNING: you need to manually create a following pf table: ACCESS
#	pfctl -t ACCESS -T add
# you need to decide on what to do with IPs listed in this table, for example (add to your pf.conf):
#	block in quick on $int from <ACCESS> 
#
# enable logging/debugging, if you like:
LOGGING=yes

# access policy is either allow or deny:
DEFAULTPOLICY=allow

#
# ===== do not modify below this line ====
#

ACTION=$1
ADDR=$2
AUID=$3
RULE=$4

if [ "$DEFAULTPOLICY" = allow ]; then
	PERMIT_ACTION=delete
	BLOCK_ACTION=add
fi
if [ "$DEFAULTPOLICY" = deny ]; then
        PERMIT_ACTION=add
        BLOCK_ACTION=delete
fi

if [ "$LOGGING" = yes ]; then
	echo `date` $ACTION $ADDR $RULE >> /tmp/access_sh.log
fi

if [ "$ACTION" = PERMIT ]; then
        /sbin/pfctl -t ACCESS -T $PERMIT_ACTION $ADDR
fi
if [ "$ACTION" = BLOCK ]; then
     	/sbin/pfctl -t ACCESS -T $BLOCK_ACTION $ADDR
fi
