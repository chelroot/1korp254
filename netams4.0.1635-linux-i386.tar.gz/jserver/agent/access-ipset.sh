#!/bin/sh

# policy is either allow or deny
DEFAULTPOLICY=allow
SETNAME=NETAMS_FILTER

## don't forget to create the set && add iptables rule like:
# /usr/sbin/ipset -N $SETNAME iphash --hashsize 1024
# /usr/sbin/ipset -F $SETNAME
# /sbin/iptables -A INPUT -m set --set $SETNAME src -j LOG

# ===== do not modify below this line ====

ACTION=$1
ADDR=`echo "$2"| sed 's/\/32$//'`
AUID=$3
RULE=$4

if [ "$DEFAULTPOLICY" = allow ]; then
	PERMIT_ACTION=--del
	BLOCK_ACTION=--add
fi
if [ "$DEFAULTPOLICY" = deny ]; then
        PERMIT_ACTION=--add
        BLOCK_ACTION=--del
fi

echo `date` $ACTION $ADDR $RULE >> /tmp/access_sh.log                	        

if [ "$ACTION" = PERMIT ]; then
        /usr/sbin/ipset $PERMIT_ACTION $SETNAME $ADDR
fi
if [ "$ACTION" = BLOCK ]; then
     	/usr/sbin/ipset $BLOCK_ACTION $SETNAME $ADDR
fi
