#!/bin/sh

### BEGIN INIT INFO
# Provides:             n4agent
# Required-Start:       $all
# Required-Stop:        $all
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description:    NETAMS4 remote pcap agent
### END INIT INFO

NAME=n4agent
DESC="NETAMS4 remote pcap agent"
DAEMON="/usr/sbin/$NAME"_pcap
PIDFILE=/var/run/$NAME.pid
SCRIPTNAME=/etc/init.d/$NAME.sh
PARAMS="-e /usr/local/netams4/jserver/agent/access-ipset.sh -c 127.0.0.1:20002 -d"
set -e

# Exit if the package is not installed
[ -x "$DAEMON" ] || exit 0

# Read configuration variable file if it is present
[ -r /etc/default/$NAME ] && . /etc/default/$NAME

. /lib/lsb/init-functions

RETVAL=0

case "$1" in
  start)
    echo -n "Starting $DESC: "
    $DAEMON -p $PIDFILE $PARAMS
    RETVAL=$?
    echo "$NAME."
    ;;
  stop)
    echo -n "Stopping $DESC: "
    kill `cat $PIDFILE`
    RETVAL=$?
    echo "$NAME."
    ;;
  restart)
	$0 stop
	sleep 1
	$0 start
    ;;
  status)
    kill -USR1 `cat $PIDFILE`
	tail -n 1 /var/log/messages
    ;;
  *)
    echo "Usage: $NAME {start|stop|restart|status}"
    exit 1
    ;;

esac

exit $RETVAL
