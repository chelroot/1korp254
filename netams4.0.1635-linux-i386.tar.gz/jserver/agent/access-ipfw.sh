#!/bin/sh

# policy is either allow or deny
DEFAULTPOLICY=allow

# default table 127 change if you need
NUM_TABLE="127"

# enable logging/debugging, if you like:
LOGGING=yes

# ===== do not modify below this line ====

ACTION=$1
ADDR=$2
AUID=$3
RULE=$4

if [ "$DEFAULTPOLICY" = allow ]; then
        PERMIT_ACTION=delete
        BLOCK_ACTION=add
fi
if [ "$DEFAULTPOLICY" = deny ]; then
        PERMIT_ACTION=add
        BLOCK_ACTION=delete
fi

if [ "$LOGGING" = yes ]; then
        echo `date` $ACTION $ADDR $RULE >> /tmp/access_sh.log
fi

if [ "$ACTION" = PERMIT ]; then
        /sbin/ipfw table $NUM_TABLE $PERMIT_ACTION $ADDR
fi
if [ "$ACTION" = BLOCK ]; then
        /sbin/ipfw table $NUM_TABLE $BLOCK_ACTION $ADDR
fi
