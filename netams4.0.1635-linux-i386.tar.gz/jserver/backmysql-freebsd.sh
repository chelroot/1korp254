#!/bin/sh

mysqldump="/usr/local/bin/mysqldump"
mysqlparam=" -u $1 " 
if [ ! $2=="" ]; then
mysqlparam=${mysqlparam} + "-p$2"
fi

bzip2="/usr/bin/bzip2"
 
dbs="netams4"
dstdir="backup/mysql"
 
fname=`date +%Y-%m-%d`
 
#remove old
/usr/bin/find $dstdir -atime +8 -delete
 
#back it up

backfile="${dstdir}/${dbs}-${fname}.sql.bz2"

$mysqldump $mysqlparam $dbs| $bzip2 -c -9 > $backfile

eval $(stat -s "$backfile")
exit $(( $st_size < 100 ))


