#!/bin/sh
#
# jserver-startup.sh
#
JAVA_HOME=../java
LIB='../lib/*:bin/'
LD_LIBRARY_PATH="../lib/so-dll/linux-i386"; export LD_LIBRARY_PATH

RUNFILE=bin/netams4-jserver.jar

RUNJAVA=$JAVA_HOME/bin/java
JAVA_OPTS=-Djava.net.preferIPv4Stack=true
MAINCLASS=com.netams.netams4.netams4
CFGFILE=../netams4.properties
DEBUG_OPTS=
LOGFILE="/dev/null"

$RUNJAVA $JAVA_OPTS $DEBUG_OPTS -cp $LIB:$RUNFILE $MAINCLASS $CFGFILE 2> $LOGFILE > $LOGFILE &
