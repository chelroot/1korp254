#!/bin/sh
#
# authserver-startup.sh
#
JAVA_HOME=../java
LIB='../lib/*'
WEBLIB='./lib/*:./war/WEB-INF/lib/*'

RUNFILE=war/WEB-INF/classes/

RUNJAVA=$JAVA_HOME/bin/java
JAVA_OPTS=
MAINCLASS=com.netams.netams4.wa.server.AuthServerApp
CFGFILE=../netams4.properties
DEBUG_OPTS=
LOGFILE="../logs/run-authserver.log"

nohup $RUNJAVA $JAVA_OPTS $DEBUG_OPTS -cp $LIB:$WEBLIB:$RUNFILE $MAINCLASS $CFGFILE 2>&1 > $LOGFILE &