function showPass(passForm) {
	var show = passForm.showpass.checked;
	if (show) {
		changeInputType(passForm.oldpass, 'text');
		changeInputType(passForm.newpass, 'text');
		changeInputType(passForm.newpass2, 'text');
	} else {
		changeInputType(passForm.oldpass, 'password');
		changeInputType(passForm.newpass, 'password');
		changeInputType(passForm.newpass2, 'password');
	}
}

function changeInputType(oldObject, oType) {
		var newObject = document.createElement('input');
		  newObject.type = oType;
		  if(oldObject.size) newObject.size = oldObject.size;
		  if(oldObject.value) newObject.value = oldObject.value;
		  if(oldObject.name) newObject.name = oldObject.name;
		  if(oldObject.id) newObject.id = oldObject.id;
		  if(oldObject.className) newObject.className = oldObject.className;
		  oldObject.parentNode.replaceChild(newObject,oldObject);
		  return newObject;		
}

function genPass(passForm) {
	passForm.gen.value = 'true';
	passForm.submit();
}

function getRadioGroupValue(radioGroupObj) {
   for (i=0; i < radioGroupObj.length; i++) {
	  if (radioGroupObj[i].checked) return radioGroupObj[i].value;
  }

  return null;
}

function payment(passForm, accid) {
	passForm.action="/payment";
	passForm.accountId.value = accid;
	passForm.submit();
}

function paymentForm(passForm, methodid) {
	if (passForm.invAmount.value==null || passForm.invAmount.value == 0) {
		alert('Не указана сумма');
	} else { 
		passForm.method.value=methodid;
		passForm.submit();
	}
}

function printInvoice(passForm, kind) {
	if (passForm.invNumber.value == null || passForm.invNumber.value == '') {
		alert("Не указан номер счета");
	} else if (passForm.invAmount.value == null || passForm.invAmount.value <= 0) {
		alert("Не указана сумма");
	} else if (passForm.invDate.value == null || passForm.invDate.value == '') {
		alert("Не указана дата");
	} else {
		var url = "/webadmin/report.print?format=" + passForm.invFormat.value 
		 	 + "&reportId=" + kind
			 + "&contractId=" + passForm.contract.value
			 + "&amount=" + passForm.invAmount.value
			 + "&number=" + passForm.invNumber.value
			 + "&date=" + passForm.invDate.value
			 + "&basis=" + passForm.invDescr.value
			 + "&locale=ru";
		window.open(url, "_blank", "resizable=1,scrollbars=1,location=no,menubar=1");
	}
}

function pay(passForm, accid) {
	passForm.action="/payments";
	passForm.accountId.value = accid;
	passForm.submit();
}

function detailService(passForm, serviceId) {
	passForm.serviceId.value = serviceId;
	passForm.submit();
}

function printTraffic(passForm, contractId, serviceId) {
		var url = "/webadmin/report.print?format=html" 
		 	 + "&reportId=TrafficReport"
			 + "&contractId=" + contractId
			 + "&serviceId=" + serviceId;
		if (passForm.startTime != undefined) {
			 url += "&startDate=" + passForm.startTime.value;	
			 url += "&endDate=" + passForm.endTime.value;	
		}
		url += "&locale=ru";
		window.open(url, "_blank", "resizable=1,scrollbars=1,location=no,menubar=1");
}

function formReport(passForm, reportId) {
	passForm.reportId.value = reportId;
	passForm.submit();
}

function formAccountReport(passForm, accountId) {
	passForm.action="/printReport";
	passForm.reportId.value = "AccountReport";
	passForm.accountId.value = accountId;
	passForm.submit();
}

function printReport(passForm, reportClass, contractId) {
	var url = "/webadmin/report.print?format=html" 
	 	 + "&reportId=" + reportClass
		 + "&contractId=" + contractId;
		if(passForm.period != undefined) {
			url += "&period=" + passForm.period.value;
		} 
		if ("CUSTOM" == passForm.period.value) {
			if(passForm.startTime != undefined) {
				url += "&startDate=" + passForm.startTime.value
				+ "&endDate=" + passForm.endTime.value;
			}
		}
		if (passForm.serviceId != undefined) {
		 url += "&serviceId=" + passForm.serviceId.value;
		}
		if (passForm.acctunitId != undefined) {
		 url += "&acctunitId=" + passForm.acctunitId.value
		}
		if (passForm.accountId != undefined) {
		 url += "&accountId=" + passForm.accountId.value
		}
		if (passForm.tariffId != undefined) {
		 url += "&tariffId=" + passForm.tariffId.value;
		}
		url += "&locale=ru";
	window.open(url, "_blank", "resizable=1,scrollbars=1,location=no,menubar=1");
}


function loadMessages(passForm, offset) {
	passForm.firstMessage.value=offset;
	passForm.submit();
}

function openMessage(passForm, id) {
	passForm.messageId.value=id;
	passForm.action="/openMessage";
	passForm.submit();
}

function closeMessage(passForm, id) {
	passForm.messageId.value=id;
	passForm.action="/closeMessage";
	passForm.submit();
}

function changePeriod(passForm) {
	if ('CUSTOM' == passForm.period.value) {
		passForm.startTime.style.display="inline";
		passForm.endTime.style.display="inline";
	} else {
		passForm.startTime.style.display="none";
		passForm.endTime.style.display="none";
	}
}

function deleteInvoice(passForm, id) {
	passForm.invoiceId.value=id;
	passForm.action="/deleteInvoice";
	passForm.submit();
}
