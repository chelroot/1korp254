#!/bin/sh
#
# radius-startup.sh
#
JAVA_HOME=../java
LIB='../lib/*:lib/*:bin/'

RUNFILE=bin/netams4-radius.jar

RUNJAVA=$JAVA_HOME/bin/java
JAVA_OPTS=-Djava.net.preferIPv4Stack=true
MAINCLASS=com.netams.radius.service.N4RadiusServerStarter
CFGFILE=../netams4.properties
DEBUG_OPTS=
LOGFILE="../logs/radius.log"

$RUNJAVA $JAVA_OPTS $DEBUG_OPTS -cp $LIB:$RUNFILE $MAINCLASS $CFGFILE 2>&1 > $LOGFILE &
