#!/bin/sh
#
# repserver-startup.sh
#
JAVA_HOME=../java
LIB='../lib/*:bin/:lib/*'

RUNFILE=bin/netams4-repserver.jar

RUNJAVA=$JAVA_HOME/bin/java
JAVA_OPTS=-Djava.net.preferIPv4Stack=true
MAINCLASS=com.netams.netams4.report.server.ReportServer
CFGFILE=../netams4.properties
DEBUG_OPTS=
LOGFILE="/dev/null"

nohup $RUNJAVA $JAVA_OPTS $DEBUG_OPTS -cp $LIB:$RUNFILE $MAINCLASS $CFGFILE 2> $LOGFILE > $LOGFILE &
